package dev.realweather.client;

import dev.realweather.MathUtil;
import dev.realweather.config.ClientConfig;
import net.minecraft.client.multiplayer.ClientLevel;

/**
 * Палитра неба, рассчитываемая непрерывно из высоты солнца и грозового затемнения (никаких
 * жёстких переключений день/вечер/ночь). Те же значения идут в шейдеры неба/облаков и в цвет тумана.
 * Все цвета линейные; тонемаппинг tm(c)=1-exp(-1.2c) одинаков в шейдерах и здесь.
 */
public final class SkyModel {
    public static final SkyModel INSTANCE = new SkyModel();

    public final float[] sunDir = new float[3];
    public final float[] zenith = new float[3];
    public final float[] horizon = new float[3];
    public final float[] sunColor = new float[3];
    public final float[] ambient = new float[3];
    public final float[] glow = new float[3];
    public float day, night, twilight, darkness, sunH;
    /** Погода дня: покрытие кучевыми (0..1), доля перистых, фаза шума облаков. */
    public float dayVar, cirrus, dayPhase;
    /** Слои облаков дня: кучевые, «башенность», слоисто-кучевые, слоистые, высококучевые, высокослоистые,
     *  перистые, перистослоистые, перисто-кучевые, линзовидные; overcast — общая пасмурность. */
    public float cumAmt, towering, scAmt, stratusAmt, acAmt, asAmt, cirrusAmt, csAmt, ccAmt, lentAmt, overcast;
    private final float[] lay = new float[10];

    private static final float[][] REGIMES = {
            // cum   tow    sc     st     ac     as     ci     cs     cc     lent
            {0.08f, 0.20f, 0f,    0f,    0f,    0f,    0.15f, 0f,    0f,    0f},     // 0 ясно
            {0.35f, 0.15f, 0f,    0f,    0f,    0f,    0.20f, 0f,    0f,    0f},     // 1 малые кучевые
            {0.55f, 0.90f, 0f,    0f,    0.10f, 0f,    0.15f, 0f,    0f,    0f},     // 2 мощные кучевые
            {0.10f, 0.20f, 0.85f, 0f,    0f,    0f,    0f,    0f,    0f,    0f},     // 3 слоисто-кучевые
            {0f,    0f,    0.20f, 0.90f, 0f,    0f,    0f,    0f,    0f,    0f},     // 4 слоистые
            {0.05f, 0.20f, 0f,    0f,    0.85f, 0f,    0.20f, 0f,    0f,    0f},     // 5 высококучевые
            {0f,    0f,    0f,    0f,    0f,    0.85f, 0.30f, 0.30f, 0f,    0f},     // 6 высокослоистые
            {0.10f, 0.20f, 0f,    0f,    0f,    0f,    0.95f, 0f,    0.30f, 0f},     // 7 перистые
            {0.05f, 0.20f, 0f,    0f,    0f,    0f,    0.40f, 0.90f, 0f,    0f},     // 8 перистослоистые + гало
            {0.25f, 0.30f, 0f,    0f,    0f,    0f,    0.10f, 0f,    0.85f, 0f},     // 9 перисто-кучевые
            {0.10f, 0.30f, 0f,    0f,    0.30f, 0f,    0.10f, 0f,    0f,    0.85f}, // 10 линзовидные
            {0.40f, 0.50f, 0.20f, 0f,    0.40f, 0f,    0.50f, 0f,    0f,    0f},     // 11 смешанный
            {0f,    0f,    0.10f, 0.95f, 0f,    0.85f, 0f,    0f,    0f,    0f},     // 12 пасмурно
    };
    // «вес» режима: ясная и кучевая погода встречается чаще
    private static final float[] REGIME_W = {2.0f, 3.0f, 1.5f, 1.0f, 1.0f, 1.0f, 0.8f, 1.0f, 0.6f, 0.6f, 0.5f, 1.0f, 0.5f};

    private static int regimeOf(long day) {
        float total = 0f;
        for (float w : REGIME_W) total += w;
        float r = hashDay(day, 7) * total, acc = 0f;
        for (int i = 0; i < REGIME_W.length; i++) {
            acc += REGIME_W[i];
            if (r < acc) return i;
        }
        return 1;
    }

    // облачность по времени суток: слои [cum, tow, sc, st, ac, as, ci, cs, cc, lent]
    private static final float[] P_NIGHT = {0.05f, 0.20f, 0f, 0f, 0f, 0.30f, 0.30f, 0.15f, 0f, 0f};
    private static final float[] P_MORNING = {0.10f, 0.20f, 0f, 0f, 0.05f, 0f, 0.85f, 0.30f, 0.35f, 0f};   // утро: перистые
    private static final float[] P_DAY = {0.55f, 0.75f, 0f, 0f, 0.10f, 0f, 0.20f, 0f, 0f, 0f};            // день: кучевые
    private static final float[] P_EVENING = {0.45f, 0.55f, 0.35f, 0f, 0.30f, 0f, 0.30f, 0f, 0.10f, 0f};  // вечер: кучевые + слоисто-кучевые
    private static final int[] SPECIAL = {3, 4, 5, 6, 10, 12};

    private static float ssf(float a, float b, float x) { return MathUtil.smooth(a, b, x); }

    /** Часы суток 0..24 (0 тиков = 6:00). */
    private static float hourOf(double dt) {
        return (float) ((((dt % 24000.0) + 24000.0) % 24000.0 / 1000.0 + 6.0) % 24.0);
    }

    private void baseClouds(float h, float dayScale, float[] out) {
        float wM = ssf(4f, 6f, h) * (1f - ssf(9f, 11f, h));
        float wD = ssf(9f, 11f, h) * (1f - ssf(15f, 17f, h));
        float wE = ssf(15f, 17f, h) * (1f - ssf(20f, 22f, h));
        float wN = Math.max(0f, 1f - wM - wD - wE);
        float sum = wM + wD + wE + wN;
        for (int i = 0; i < 10; i++) {
            float v = (P_MORNING[i] * wM + P_DAY[i] * wD + P_EVENING[i] * wE + P_NIGHT[i] * wN) / sum;
            out[i] = (i == 1) ? v : Math.min(1f, v * dayScale);        // «башенность» от дня не зависит
        }
    }

    /** Вектор облачности для суток d в данный час: по времени суток, у части дней — «особая» погода. */
    private void dayVector(long d, float h, float[] out) {
        baseClouds(h, 0.6f + 0.8f * hashDay(d, 3), out);
        if (hashDay(d, 7) < 0.22f) {                                    // ~каждый пятый день пасмурный/необычный
            float[] sp = REGIMES[SPECIAL[(int) (hashDay(d, 11) * SPECIAL.length) % SPECIAL.length]];
            for (int i = 0; i < 10; i++) out[i] = MathUtil.lerp(out[i], sp[i], 0.65f);
        }
    }

    private final float[] tmpA = new float[10], tmpB = new float[10];

    /** Облака: утром перистые, днём кучевые, вечером кучевые и слоисто-кучевые; дни отличаются друг от друга. */
    private void computeClouds(double dt, double dayF) {
        int cfg = ClientConfig.CLOUD_REGIME.get();
        if (!ClientConfig.CLOUD_VARIETY.get() && cfg < 0) cfg = 1;
        if (cfg >= 0) {
            System.arraycopy(REGIMES[cfg], 0, lay, 0, 10);
        } else {
            long d = (long) Math.floor(dayF);
            float f = (float) (dayF - d);
            float h = hourOf(dt);
            dayVector(d, h, tmpA);
            dayVector(d + 1, h, tmpB);
            float t = MathUtil.smooth(0.75f, 1.0f, f);
            for (int i = 0; i < 10; i++) lay[i] = MathUtil.lerp(tmpA[i], tmpB[i], t);
        }
        cumAmt = lay[0]; towering = lay[1]; scAmt = lay[2]; stratusAmt = lay[3]; acAmt = lay[4];
        asAmt = lay[5]; cirrusAmt = lay[6]; csAmt = lay[7]; ccAmt = lay[8]; lentAmt = lay[9];
        overcast = Math.min(1f, stratusAmt * 0.9f + asAmt * 0.7f + scAmt * 0.4f + csAmt * 0.25f);
    }

    public void update(ClientLevel level, float pt, double cx, double cz, double now) {
        double dt = ClientStorms.dayTime(level, now);
        float tod = level.dimensionType().timeOfDay((long) dt);
        double th = tod * Math.PI * 2.0;
        double dayF = dt / 24000.0;
        dayVar = dayNoise(dayF, 0);
        cirrus = 0.15f + 0.85f * dayNoise(dayF, 1);
        dayPhase = (float) (dayF * 0.9);
        computeClouds(dt, dayF);
        sunDir[0] = (float) -Math.sin(th);
        sunDir[1] = (float) Math.cos(th);
        sunDir[2] = 0f;
        sunH = sunDir[1];
        darkness = ClientStorms.darknessAt(cx, cz, now) * ClientConfig.STORM_DARKNESS.get().floatValue();

        day = MathUtil.smooth(-0.10f, 0.22f, sunH);
        night = 1f - MathUtil.smooth(-0.22f, 0.02f, sunH);
        float q = (sunH + 0.02f) / 0.16f;
        twilight = (float) Math.exp(-q * q);

        for (int i = 0; i < 3; i++) {
            zenith[i] = MathUtil.lerp(NIGHT_Z[i], DAY_Z[i], day);
            horizon[i] = MathUtil.lerp(NIGHT_H[i], DAY_H[i], day) + twilight * TW_H[i] * 0.55f;
            ambient[i] = MathUtil.lerp(AMB_NIGHT[i], AMB_DAY[i], day);
            glow[i] = twilight * SUN_LOW[i];
        }
        zenith[0] += twilight * 0.03f; zenith[1] += twilight * 0.02f; zenith[2] += twilight * 0.07f;
        ambient[0] += twilight * 0.22f; ambient[1] += twilight * 0.12f; ambient[2] += twilight * 0.10f;

        float sunVis = MathUtil.smooth(-0.08f, 0.06f, sunH);
        // пропускание атмосферы: воздушная масса по Касатену–Янгу, у горизонта солнце краснеет и тускнеет
        double sinH = Math.max(sunH, 0.0);
        double deg = Math.toDegrees(Math.asin(Math.max(0.0, Math.min(1.0, sinH))));
        double am = Math.min(40.0, 1.0 / (sinH + 0.50572 * Math.pow(deg + 6.07995, -1.6364)));
        float[] tau = {0.15f, 0.20f, 0.35f};
        float[] base = {1.0f, 0.97f, 0.92f};
        for (int i = 0; i < 3; i++) {
            float tr = (float) Math.pow(Math.exp(-tau[i] * am), 0.6);
            sunColor[i] = base[i] * tr * 1.5f * sunVis;
        }

        // грозовое затемнение: небо уходит в серый, солнце гаснет
        float dk = Math.max(darkness, overcast * 0.65f);       // шторм или сплошная облачность
        float dayMix = 0.25f + 0.75f * day;
        for (int i = 0; i < 3; i++) {
            zenith[i] = MathUtil.lerp(zenith[i], STORM_Z[i] * dayMix, dk);
            horizon[i] = MathUtil.lerp(horizon[i], STORM_H[i] * (0.2f + 0.8f * day), dk * 0.85f);
            sunColor[i] *= 1f - 0.8f * dk;
            glow[i] *= 1f - dk;
            ambient[i] *= 1f - 0.45f * dk;
        }
    }

    /** Цвет тумана = тонемаппированный цвет горизонта (чтобы дальний рельеф сливался с небом). */
    public void fogColor(float[] out) {
        for (int i = 0; i < 3; i++) out[i] = 1f - (float) Math.exp(-horizon[i] * 1.2f);
    }
}
