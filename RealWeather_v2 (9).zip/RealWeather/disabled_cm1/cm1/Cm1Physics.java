package dev.realweather.cm1;

import dev.realweather.config.RWConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Ветер CM1 как сила на мобов и предметы (серверная сторона). Игроков двигает клиент по тем же данным. */
public final class Cm1Physics {
    private Cm1Physics() {}

    private static boolean affects(Entity e) {
        if (!e.isAlive() || e.isSpectator() || e.isPassenger()) return false;
        if (e instanceof EnderDragon || e instanceof WitherBoss) return false;
        return e instanceof LivingEntity || e instanceof ItemEntity || e instanceof FallingBlockEntity;
    }

    /** Перевод ветра CM1 (м/с) в блоки/тик с порогом «обычного» ветра: двигают только сильные порывы. */
    public static void toBlocks(double[] uvw, Cm1Mapping m, double gain, double[] out) {
        double sp = Math.hypot(uvw[0], uvw[1]);
        double f = sp > 15.0 ? (sp - 15.0) / sp : 0.0;
        double wv = Math.abs(uvw[2]) > 5.0 ? Math.signum(uvw[2]) * (Math.abs(uvw[2]) - 5.0) : 0.0;
        out[0] = uvw[0] * f / m.mpbH / 20.0 * gain;
        out[2] = uvw[1] * f / m.mpbH / 20.0 * gain;
        out[1] = wv / m.mpbV / 20.0 * gain;
    }

    public static void apply(ServerLevel level) {
        Cm1Window win = Cm1Manager.current();
        if (win == null || win.mapping() == null) return;
        double gain = RWConfig.CM1_WIND_GAIN.get();
        double mult = RWConfig.ENTITY_MULT.get();
        if (gain <= 0 || mult <= 0) return;
        AABB box = new AABB(win.minX(), win.minY(), win.minZ(), win.maxX(), Math.min(win.maxY(), win.minY() + 400), win.maxZ());
        double[] uvw = new double[3], b = new double[3];
        List<Entity> list = level.getEntities((Entity) null, box, Cm1Physics::affects);
        for (Entity e : list) {
            if (e instanceof net.minecraft.world.entity.player.Player) continue;
            if (!win.wind(e.getX(), e.getY(), e.getZ(), uvw)) continue;
            toBlocks(uvw, win.mapping(), gain, b);
            if (b[0] == 0 && b[1] == 0 && b[2] == 0) continue;
            double k = Mth.clamp(0.12 * mult, 0.0, 0.4);
            Vec3 c = e.getDeltaMovement();
            double nx = c.x + (b[0] - c.x) * k, nz = c.z + (b[2] - c.z) * k;
            double ny = c.y + (b[1] - c.y) * k + (b[1] > 0.02 ? 0.0784 * Mth.clamp(b[1] / 0.25, 0.0, 1.0) : 0.0);
            if (!Double.isFinite(nx) || !Double.isFinite(ny) || !Double.isFinite(nz)) continue;
            double hs = Math.sqrt(nx * nx + nz * nz);
            if (hs > 1.6) { nx *= 1.6 / hs; nz *= 1.6 / hs; }
            ny = Mth.clamp(ny, -1.0, 1.0);
            e.setDeltaMovement(nx, ny, nz);
            e.hurtMarked = true;
        }
    }
}
