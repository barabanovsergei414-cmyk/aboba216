import numpy as np
from scipy.io import netcdf_file
nx,ny,nz = 40,36,30
dx=1000.0
xh=(np.arange(nx)+0.5)*dx/1000; yh=(np.arange(ny)+0.5)*dx/1000          # км
zh=np.array([0.1+0.62*k+0.01*k*k for k in range(nz)])/1.0               # км, растяжение
zf=np.concatenate([[0.0],0.5*(zh[1:]+zh[:-1]),[zh[-1]+0.5]])            # nz+1
X,Y=np.meshgrid(xh,yh)                                                  # (ny,nx)
def gauss(cx,cy,sx):
    return np.exp(-(((X-cx)**2+(Y-cy)**2)/(2*sx**2)))
up = gauss(25.5,14.5,3.0)
qc=np.zeros((1,nz,ny,nx),'f'); qr=np.zeros((1,nz,ny,nx),'f'); qi=np.zeros((1,nz,ny,nx),'f')
for k in range(nz):
    prof=np.exp(-((zh[k]-5.0)/4.0)**2)
    qc[0,k]=(0.003*prof*up).astype('f'); qi[0,k]=(0.001*(zh[k]>9)*up).astype('f')
    qr[0,k]=(0.004*np.exp(-((zh[k]-1.5)/2.0)**2)*gauss(27.5,16.5,2.0)).astype('f')
# ветер: фон + вихрь Ранкина (центр 30.5,20.5 км)
cxv,cyv=30.5,20.5
def vortex(Xg,Yg,vmax=60.0,rc=1.5):
    r=np.hypot(Xg-cxv,Yg-cyv)+1e-6
    vt=np.where(r<rc,vmax*r/rc,vmax*rc/r)
    return -vt*(Yg-cyv)/r, vt*(Xg-cxv)/r
xf=np.arange(nx+1)*dx/1000; yf=np.arange(ny+1)*dx/1000
Xu,Yu=np.meshgrid(xf,yh); Xv,Yv=np.meshgrid(xh,yf)
uu=np.zeros((1,nz,ny,nx+1),'f'); vv=np.zeros((1,nz,ny+1,nx),'f'); ww=np.zeros((1,nz+1,ny,nx),'f')
for k in range(nz):
    f=np.exp(-zh[k]/1.5)
    uu[0,k]=(vortex(Xu,Yu)[0]*f+8.0).astype('f'); vv[0,k]=(vortex(Xv,Yv)[1]*f+3.0).astype('f')
for k in range(nz+1):
    ww[0,k]=(25.0*np.exp(-((zf[k]-6.0)/4.0)**2)*up).astype('f')
import sys
ver=int(sys.argv[1])
nc=netcdf_file(f'cm1out_00000{ver}.nc','w',version=ver)
nc.createDimension('time',None)
for n,l in (('xh',nx),('xf',nx+1),('yh',ny),('yf',ny+1),('zh',nz),('zf',nz+1)): nc.createDimension(n,l)
def mk(name,typ,dims,data):
    v=nc.createVariable(name,typ,dims); v[:]=data; return v
mk('time','f',('time',),np.array([4513.0],'f'))
mk('xh','f',('xh',),xh.astype('f')); mk('yh','f',('yh',),yh.astype('f')); mk('zh','f',('zh',),zh.astype('f'))
mk('xf','f',('xf',),xf.astype('f')); mk('yf','f',('yf',),yf.astype('f')); mk('zf','f',('zf',),zf.astype('f'))
mk('qc','f',('time','zh','yh','xh'),qc); mk('qi','f',('time','zh','yh','xh'),qi); mk('qr','f',('time','zh','yh','xh'),qr)
mk('u','f',('time','zh','yh','xf'),uu); mk('v','f',('time','zh','yf','xh'),vv); mk('w','f',('time','zf','yh','xh'),ww)
nc.close()
np.save('truth_qc.npy',qc[0]); np.save('truth_w.npy',ww[0]); np.save('truth_qr.npy',qr[0])
print("ok",ver, "argmax w mid:", np.unravel_index(np.argmax(ww[0,int(0.3*nz)]),(ny,nx)))
